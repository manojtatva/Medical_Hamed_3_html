// Importing specific gulp API functions lets us write them below as series() instead of gulp.series()
// Initialize modules
const { src, dest, watch, series, parallel } = require('gulp');
const sourcemaps = require('gulp-sourcemaps');
const sass = require('gulp-sass');
const concat = require('gulp-concat');
const plumber = require("gulp-plumber");
const uglify = require('gulp-uglify');
const postcss = require('gulp-postcss');
const autoprefixer = require('autoprefixer');
const imagemin = require('gulp-imagemin');
const cssnano = require('cssnano');
// const del = require('del');
// const browserSync = require('browser-sync').create();
var replace = require('gulp-replace');

// File paths
const files = {
    scssPath: 'assets/scss/**/*.scss',
    jsPath: 'assets/js/**/*.js',
    vendorJS: 'assets/js/vendor/*.js',
    images: 'assets/images/*.!(db)',
    fonts: 'assets/fonts/*.{ttf,woff,eof,svg}',
}

// function delTask() {
//     return del(["public/fonts","public/js", "public/css","public/images"]);
// }

function scssTask() {
    return src(files.scssPath)
    .pipe(sourcemaps.init()) 
    .pipe(plumber())
    .pipe(sass()) 
        // .pipe(browserSync.stream())
        .pipe(postcss([autoprefixer(), cssnano()])) 
        .pipe(sourcemaps.write('.')) 
        .pipe(dest('public/css')
            ); 
    }

    function jsTask() {
        return src([
            files.jsPath
            ])
        .pipe(plumber())
        .pipe(concat('main.js'))
        .pipe(uglify())
        .pipe(dest('public/js')
            );
    }
    function vendorjsTask() {
        return src([
            'node_modules/jquery/dist/jquery.min.js',
            'node_modules/jquery-migrate/dist/jquery-migrate.min.js',
            'node_modules/bootstrap/dist/js/bootstrap.min.js',
            'node_modules/select2/dist/js/select2.full.min.js',
            'node_modules/owl.carousel/dist/owl.carousel.min.js',
            'node_modules/lightgallery/dist/js/lightgallery-all.min.js',
            'node_modules/bootstrap-datepicker/dist/js/bootstrap-datepicker.min.js',
            'node_modules/dropzone/dist/min/dropzone.min.js',
            'node_modules/jquery-range/jquery.range-min.js',
            'node_modules/easy-autocomplete/dist/jquery.easy-autocomplete.min.js',
            files.vendorJS,
            ])
        .pipe(plumber())
        .pipe(concat('vendor.js'))
        .pipe(uglify())
        .pipe(dest('public/js')
            );
    }
    function fontTask() {
        return src([
            files.fonts
            ])
        .pipe(plumber())
        .pipe(dest('public/fonts')
            );
    }

    function imageTask() {
        return src([
            files.images
            ])
        .pipe(plumber())
        .pipe(imagemin())
        .pipe(dest('public/images')
            );
    }

// Cachebust
var cbString = new Date().getTime();
function cacheBustTask() {
    return src(['index.html'])
    .pipe(replace(/cb=\d+/g, 'cb=' + cbString))
    .pipe(dest('.'));
}

// Watch SCSS and JS files for changes
function watchTask() {

 // browserSync.init();

//  browserSync.init({
//     server: {
//       baseDir: './'
//     },
//     ui: false
// })

watch([files.scssPath, files.jsPath, files.vendorJS,files.fonts,files.images],
    series(
            // delTask,
            vendorjsTask,
            fontTask,
            imageTask,
            parallel(scssTask, jsTask),
            cacheBustTask
            )
    );
    // watch('./*.html').on('change', browserSync.reload);
}

// Export the default Gulp task so it can be run
exports.default = series(
    // delTask,
    vendorjsTask,
    fontTask,
    imageTask,
    parallel(scssTask, jsTask),
    cacheBustTask,
    watchTask
    );