function checklanguage(){
    if( $('.lang-dropdown > span').text() == 'EN')
          {
            $('html').attr('dir','');
            $('link[rel="stylesheet"]').attr('href','public/css/style.css');
            $('.ar-text').hide();
            $('.en-text').show();
                var owldataCrousal = $('.owl-carousel')
                owldataCrousal.each(function(){
                var carouselData = $(this).data();
                carouselData['owl.carousel'].options.rtl = false;
                $(this).trigger('refresh.owl.carousel'); 
                $(this).removeClass('owl-rtl'); 
                });  
          }
        else if( $('.lang-dropdown > span').text() == 'عربى')
        {
            $('html').attr('dir','rtl');
            $('link[rel="stylesheet"]').attr('href','public/css/main-rtl.css');    
            $('.ar-text').show();
            $('.en-text').hide(); 
            var owldataCrousal = $('.owl-carousel')
            owldataCrousal.each(function(){
            var carouselData = $(this).data();
            carouselData['owl.carousel'].options.rtl = true;
            $(this).trigger('refresh.owl.carousel');
            $(this).addClass('owl-rtl');   
             });   
        }
 }
/* Owl Calculated slider width */


function sliderwidth() {
  var windowwidth = $(window).width();
  var sliderwidth = $('.sliderwidth-content').width();
  var remaingwidth = (windowwidth - sliderwidth) / 2;
  var slidercontetWidth = sliderwidth + remaingwidth;
  $('.sliderwidth-content').css("width", slidercontetWidth);
}
/* Owl choose Calculated slider width  */
function TimeSliderwidth() {
  var windowwidth = $(window).width();
  var sliderwidth = $('.choose-time-slide').width();
  var calendercontentWidth = $('.calender-content').width();
  var remaingwidth = (windowwidth - sliderwidth) / 2;
  var slidercontetWidth = sliderwidth + remaingwidth;
  var choosetimeslideWidth = slidercontetWidth - calendercontentWidth;
  $('.choose-time-slide').css("width", choosetimeslideWidth + 157);
}
/* Owl choose Calculated slider width  */
function testlabsliderwidth() {
  var windowwidth = $(window).width();
  var sliderwidth = $('.testlab-sliderwidth').width();
  var remaingwidth = (windowwidth - sliderwidth) / 2;
  var slidercontetWidth = sliderwidth + remaingwidth;
  $('.testlab-sliderwidth').css("width", slidercontetWidth);
}

/* profile gallary section bottom image provide a same height*/
function profilerImageWidth() {
  var imagewidth = $('.profiler-images-list li img').width();
  $('.profiler-images-list li img').css('height', imagewidth);
  $('.profiler-images-list .box-fill').css('height', imagewidth);
}

function showpassword() {
        var x = document.getElementById("passwordInput");
        if (x.type === "password") {
        x.type = "text";
        } else {
        x.type = "password";
        }
  }


$(document).ready(function() {
    // $('a').click(function(e){
    //     e.preventDefault();
    // });

  /*Select2 using for dropdown*/
  $(".lookingfor").select2({
      placeholder: "Looking For",
      allowClear: true,
      minimumResultsForSearch: -1,
  });

  /*Select2 using for dropdown*/
  $(".city").select2({
      placeholder: "City",
      allowClear: true,
      minimumResultsForSearch: -1
  });

 /*Language select dropdown*/
//   $('.lang-dropdown').click(function() {
//       $('.lang-hidden-dropdown').fadeToggle("slow");
//   });




  /*Slider width function run on device grater than 767 */
  if ($(window).width() > 767) {
      sliderwidth();
      TimeSliderwidth();
      testlabsliderwidth();
  }
    /*Home page near lab slider */
    var labslider = $(".lab-slider").owlCarousel({
        loop: true,
        rtl: false,
        responsive: {
            0: {
                items: 2.70,
            },
            576: {
                items: 4.70,
            },
            768: {
                items: 4.70,
                margin: 50,
            },
            991: {
                items: 5.70,
                margin: 50,
            },
            1199: {
    
                items: 6.70,
                margin: 60,
            },
            1400: {
                items: 7.70,
                margin: 60,
            }
        }
    });

    $(".offer-slider").owlCarousel({
        loop: true,
        rtl:false,
        responsive: {
            0: {
                items: 1.20,
                margin: 0,
            },
    
            576: {
                items: 1.90,
                margin: 0,
            },
            768: {
              items: 1.90,
              margin: 30,
            },
    
            1199: {
                items: 2.90,
                margin: 66,
            }
        }
    });
    $('.timings-location-slider').owlCarousel({
        rtl:false,
        loop: false,
        margin: 0,
        nav: true,
        items: 1,
        navText: ["<img src='public/images/left-arrow.svg'>", "<img src='public/images/right-arrow.svg'>"]
    });

     $('.reviews-slider').owlCarousel({
        rtl:false,
        loop: true,
        nav: false,
        responsive: {

            0: {
                items: 1.25,
                margin: 0,
            },

            767: {
                items: 2.25,
                margin: 10,
            },
            991: {
                items: 2.75,
                margin: 30,
            }
        }
    });


    /*Lab page  test lab slider */
    $(".tests-lab-slider").owlCarousel({
        loop: true,
        rtl:false,
        responsive: {
            0: {
                items: 1.20,
                margin: 1,
            },
            576: {
                items: 1.70,
                margin: 15,
            },
            1440: {
                items: 2.85,
                margin: 30,
            },
        1450: {
                items: 2.9,
                margin: 30,
            }
        }
    });

    // $('.lang-hidden-dropdown .ar').click(function(){
      
    // });
  /*Home page offer lab slider */
 /*profile page Time loaction slider */
  

/*profile rating  custome slider for next */
  $('.rating-slide-nav .time-slide-next').click(function() {
    $('.reviews-slider').trigger('next.owl.carousel', [300]);
  });
  /*profile rating  custome slider for prev*/
  $('.rating-slide-nav .time-slide-prev').click(function() {
    $('.reviews-slider').trigger('prev.owl.carousel', [300]);
     });


  $('#toggle').click(function() {
    if($(window).width() < 991){
        $(this).toggleClass('active');
        $('#overlay').toggleClass('open');
        if ($('#overlay').hasClass('open')) {
            $('html').css('overflow', 'hidden');
        } else {
            $('html').css('overflow', 'inherit');
        }
    }
});

  
  $('.overlay-menu a').click(function() {
    if($(window).width() < 991){
      $('.button_container').toggleClass('active');
      $('#overlay').toggleClass('open');
    }
  });
  
  /*near by doctor list gallery */
  $(".dli-gallery, .search-item-gallery").lightGallery();


/*circle progress bar */
  $(".progress").each(function() {
      var value = $(this).attr('data-value');
      var left = $(this).find('.progress-left .progress-bar');
      var right = $(this).find('.progress-right .progress-bar');

      if (value > 0) {
          if (value <= 50) {
              right.css('transform', 'rotate(' + percentageToDegrees(value) + 'deg)')
          } else {
              right.css('transform', 'rotate(180deg)')
              left.css('transform', 'rotate(' + percentageToDegrees(value - 50) + 'deg)')
          }
      }

  })

  function percentageToDegrees(percentage) {
      return percentage / 100 * 360
  }
  /*profile page in doctor details gallery change image when you click on small images */
  $('.profiler-images-list li:not(:last-child)').click(function() {
      var imgpath = $(this).find('img').attr('src');
      $('.profiler-images > img').attr('src', imgpath);
  });
/*profile page in doctor details in gallery  when click on 6+ images */
  var methods = $('.profiler-images-list');

  $('.box-fill').on('click', function() {
      methods.lightGallery();
  });
  methods.on('onCloseAfter.lg', function(event) {
      methods.data('lightGallery').destroy(true);
  });

/*profile page datepicker */
  var nowDate = new Date();
  var today = new Date(nowDate.getFullYear(), nowDate.getMonth(), nowDate.getDate(), 0, 0, 0, 0);
  $('.booking-date').datepicker({
      daysOfWeekDisabled: "0",
      todayHighlight: true,
      startDate: today,
      toggleActive: true,
      maxViewMode: 0,
  });

  $(".date input").datepicker({ 
    autoclose: true,
    // dir:'rtl',
});

  $(".coupon").click(function() {
      $(".coupon-code-form").show();
      $(".coupon").hide();
  });

  $("a[href='#']").click(function(e) {
      e.preventDefault();
  });

  // var myDropzone = new Dropzone("#prescription-upload", { url: "/file/post"});

  /* Cutome navigation in choose time slider profile page */
  var timeSliderCraousal = $('.chose-time-slider');
  $('.choose-time-slide-nav .time-slide-next').click(function() {
      timeSliderCraousal.trigger('next.owl.carousel', [300]);
  });
  $('.choose-time-slide-nav .time-slide-prev').click(function() {
      timeSliderCraousal.trigger('prev.owl.carousel', [300]);
  });

/* chosse option in lab page test */
  $('.pickup-option a').click(function() {
      $('.pickup-option a').removeClass('active');
      $(this).addClass('active');
  });
  /* search page find near by option selected*/
  $('.find-nearby ul li a').click(function() {
      $('.find-nearby ul li a').removeClass('active');
      $(this).addClass('active');
  });

  /*Filter page select opiton */
  $('.search-filter .filter-list li a').click(function(){
      $(this).parents('.filter-list').children('li').removeClass('active');
      $(this).parent('li').addClass('active');
  });
   $('.distance-range').jRange({
        from: 0,
        to: 25,
        step: 5,
        scale: [0, 5,10 , 15 , 20, 25],
        format: '%s',
        width: 325,
        showLabels: true,
        snap: true,
        theme: 'themeprimary',
    });
    $('.consult-fee').jRange({
        from: 0,
        to: 50,
        step: 10,
        scale: [0,10,20,30,40,50],
        format: '%s',
        width: 325,
        showLabels: true,
        snap: true,
        isRange : true,
        theme: 'themeprimary',
    });
    $('.experience-range').jRange({
        from: 0,
        to: 40,
        step: 10,
        scale: [0, 10 , 20 , 30, 40],
        format: '%s',
        width: 325,
        showLabels: true,
        snap: true,
        theme: 'themeprimary',
    });

    $("#passwordInput").on('keyup', function (e) {        
        if ($('#passwordInput').val().length > 0) 
        {  
            $('.show-password').show();
        }  
        else{
            $('.show-password').hide();
        }
    });
    
    $('.show-password').click(function(){
        if ($('#passwordInput').val().length > 0) 
        {  
            showpassword();
        }
        $(this).toggleClass('show-pass');        
    });

    $('.forgotpassword').click(function(){
        $(this).parents('.dropdown-content').addClass('forgot-password-screen');
    });
    $('.backtologin').click(function(){
        $(this).parents('.dropdown-content').removeClass('forgot-password-screen');
    });

      
      $('.dropdown > a').click(function(){
          $(this).siblings('.dropdown-content').removeClass('forgot-password-screen');
                     
          if($(window).height() > 520){
                $('.dropdown-content .dropdown-inner-area').css({'align-items':'center'});
             }
             else
            {
                $('.dropdown-content .dropdown-inner-area').css({'align-items':'none'});
            }
          if($(window).width() <  576 ){
              $('html').css({'overflow': 'hidden'});
          }  
        });
      $('.close-login').click(function(){
          $(this).parents('li').removeClass('open');
          $(this).parents('.dropdown-content').removeClass('forgot-password-screen');
          $('html').css({'overflow': 'auto'});
        });

        $('.call-client').click(function(){
            $(this).parents('.appointment-client-content').children('.appointment-client-time-detail').slideToggle();
        });  
        $('.report-graph-action a').click(function(){
            $(this).addClass('active').siblings('a').removeClass('active');
        });

          $(".right-header ul > li > a").click(function() {
            $(this).parents('li').siblings('li').removeClass('open');
            $(this).parents('li').toggleClass('open');
        });

   
        $('.add-edu-detail').click(function(){
            $(this).hide();
            $('.add-education-details .education-form').slideDown();
        });
        $('.education-form-action button').click(function(){
            $('.add-education-details .education-form').slideUp(function(){
                $('.add-edu-detail').show();
            });
            
        });

        $("#search-multiselect1").select2({
            closeOnSelect : false,
			placeholder : " ",
			allowHtml: true,
			allowClear: true,
            tags: true,
            containerCssClass : "search-multipule-option",
            dropdownCssClass  : 'search-multipule'
        });

        $("#search-specilaization, #search-services").select2({
            closeOnSelect : false,
			placeholder : " ",
			allowHtml: true,
			allowClear: true,
            tags: true,
            containerCssClass : "search-specilaization-option",
            dropdownCssClass  : 'search-multipule search-specilaization-content'
        });

        $('.clinic-info-action a').click(function(){
            $(this).parents('.login-info-outer').addClass('complete-steps');
        });

        if($('#profileAccodian .login-info-outer .collapse').hasClass('show')){
            $(this).parents('.card').addClass('avs');
        }
        
        $('#profileAccodian').on('show.bs.collapse', function(e) {
            $(e.target).parents('.login-info-outer').addClass('active');
        })
        .on('hide.bs.collapse', function(e) {
            $(e.target).parents('.login-info-outer').removeClass('active');
        });



        var options = {
            data: ["blue", "green", "pink", "red", "yellow"]
        };
        $("#addressHome").easyAutocomplete(options);
        $(".form-group input" ).blur(function() {
            if ($(this).val().length > 0) 
             {  
                $(this).parents('.form-group').addClass('formvalue');
             }
             else{
                $(this).parents('.form-group').removeClass('formvalue');
             }
          });

          $(".easy-autocomplete input").focus(function() {
               $(this).parents('.form-group').addClass('formvalue');
          });
         
          $('.prev-seach-location .prev-location-list .seeall-btn').click(function(e){
            e.preventDefault();
               $('.prev-seach-location .prev-location-list .seeall-btn span').text("Select");
               $(this).children('span').text("Selected");
               $('.add-clinic-modal .modal-footer').show();
          });  

          $(".set-clinic-time-slider").owlCarousel({
              loop:true,
              rtl:false,
              responsive: {
                0: {
                    items: 1.20,
                    margin:10,
                },
                576: {
                    items: 1.80,
                    margin:30,
                },
                768: {
                    items: 2.40,
                    margin:30,
                },
                1200: {
                    items: 2.70,
                    margin:30,
                }
            }
              
          });

          $('.clinci-info-action button').click(function(){
              setTimeout(function(){ 
                 $('body').addClass('modal-open'); 
                 $('html').css('overflow','hidden')
                }, 600);               
          });
          
          $('.modal .modal-header .close').click(function(){
                 $('html').css('overflow','visible')
          });
          
          $('.lang-hidden-dropdown .ar').click(function(){
             var selectText = $(this).text();
              $('.lang-dropdown > span').text(selectText);            
                checklanguage();  
           });
          $('.lang-hidden-dropdown .en').click(function(){
              $('.lang-dropdown > span').text('EN');
              checklanguage();             
          });
          
});

$(window).load(function() {
    /* profile page more than 6 gallery list is hide*/
  var lenghtGallery = $('.profiler-images-list li').length;
  if (lenghtGallery > 5) {
      $('.profiler-images-list li:lt(5)').css({
          'position': 'static',
          'opacity': 1,
          'visibility': 'visible',
      });
  }
  profilerImageWidth();
});
$(window).resize(function() {

  if ($(window).width() > 767) {
      sliderwidth();
      TimeSliderwidth();
      testlabsliderwidth();      
  }
  profilerImageWidth();
});

window.onbeforeunload = function() {
    localStorage.setItem("your-setting-name", $('.lang-dropdown > span').text());

};

window.onload = function() {
    var name = localStorage.getItem("your-setting-name");
    if (name !== null) {
        $('.lang-dropdown > span').text(name)
    }
    setTimeout(function(){  checklanguage(); }, 0);
};  